Data Agent - Generative AI Academic Report

Revised 18 October 2026: 17 pages, seven wine-quality application screenshots,
including two large landscape desktop plates. All website images show the
winequality-red dataset. Other experimental datasets are identified in the text.

Main title: Data Agent
Subtitle: An Integrated Platform for Conversational Analytics and Automated Machine Learning
Student: Bharath Linga Reddy Palem | 23STUCHH010306
Faculty mentor: Sarit Chandra

Build from this folder using an installed LaTeX distribution:
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape Data_Agent_Generative_AI_Report.tex
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape Data_Agent_Generative_AI_Report.tex

Keep data_agent_assets beside the .tex file. The lscape package and pdfTeX page
rotation create the final two landscape plates. The certificate is intentionally
unsigned for faculty verification. Cleaning screenshots show a preview only.
The saved wine model result is described with its original-data limitations.
